-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  jeu. 31 jan. 2019 à 21:40
-- Version du serveur :  5.7.21
-- Version de PHP :  5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `projet3`
--

-- --------------------------------------------------------

--
-- Structure de la table `billets`
--

DROP TABLE IF EXISTS `billets`;
CREATE TABLE IF NOT EXISTS `billets` (
  `billet_id` int(11) NOT NULL AUTO_INCREMENT,
  `billet_date` date NOT NULL,
  `billet_title` varchar(255) NOT NULL,
  `billet_content` text NOT NULL,
  PRIMARY KEY (`billet_id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `billets`
--

INSERT INTO `billets` (`billet_id`, `billet_date`, `billet_title`, `billet_content`) VALUES
(1, '2018-11-28', 'Chapitre 1 : Bienvenue !', '<p>Lorem Elsass ipsum flammekueche rhoncus commodo picon bi&egrave;re Pellentesque dui dolor Huguette messti de Bischheim wurscht r&eacute;chime elit leverwurscht Miss Dahlias varius tellus lacus libero, quam, hopla placerat rossbolla risus, leo non geht\'s libero. vielmols, Oberschaeffolsheim wie non consectetur ullamcorper n&uuml;dle Pfourtz ! gravida condimentum Chulia Roberstau Salut bisamme knepfle suspendisse nullam dignissim hopla ornare&nbsp; hop sagittis in, m&auml;nele Yo d&ucirc;. lotto-owe schneck turpis bredele salu ante ftomi! knack bissame chambon hopla Oberschaeffolsheim blottkopf, auctor, und Mauris ac DNA, jetz gehts los habitant Morbi Christkindelsm&auml;rik s\'guelt eleifend Sp&auml;tzle pellentesque Verdammi rucksack ac Coop&eacute; de Truchtersheim kartoffelsalad Gal ! merci vielmols purus semper schpeck senectus so Hans Richard Schirmeck Wurschtsalad Gal. vulputate tchao bissame baeckeoffe Racing. sit gal aliquam ge&iuml;z tellus amet, porta m&eacute;t&eacute;or hoplageiss id, gewurztraminer tristique barapli kuglopf leo et eget Chulien id ch\'ai amet morbi mollis munster Salu bissame yeuh. adipiscing amet schnaps ornare sed libero, Strasbourg Kabinetpapier sit mamsell sed elementum quam. kougelhopf Heineken hopla Carola sit turpis,</p>'),
(2, '2019-01-14', 'Chapitre 2 : tempête de neige', '<p>Lorem Elsass ipsum flammekueche rhoncus commodo picon bi&egrave;re Pellentesque dui dolor Huguette messti de Bischheim wurscht r&eacute;chime elit leverwurscht Miss Dahlias varius tellus lacus libero, quam, hopla placerat rossbolla risus, leo non geht\'s libero. vielmols, Oberschaeffolsheim wie non consectetur ullamcorper n&uuml;dle Pfourtz ! gravida condimentum Chulia Roberstau Salut bisamme knepfle suspendisse nullam dignissim hopla ornare&nbsp; hop sagittis in, m&auml;nele Yo d&ucirc;. lotto-owe schneck turpis bredele salu ante ftomi! knack bissame chambon hopla Oberschaeffolsheim blottkopf, auctor, und Mauris ac DNA, jetz gehts los habitant Morbi Christkindelsm&auml;rik s\'guelt eleifend Sp&auml;tzle pellentesque Verdammi rucksack ac Coop&eacute; de Truchtersheim kartoffelsalad Gal ! merci vielmols purus semper schpeck senectus so Hans Richard Schirmeck Wurschtsalad Gal. vulputate tchao bissame baeckeoffe Racing. sit gal aliquam ge&iuml;z tellus amet, porta m&eacute;t&eacute;or hoplageiss id, gewurztraminer tristique barapli kuglopf leo et eget Chulien id ch\'ai amet morbi mollis munster Salu bissame yeuh. adipiscing amet schnaps ornare sed libero, Strasbourg Kabinetpapier sit mamsell sed elementum quam. kougelhopf Heineken hopla Carola sit turpis,</p>'),
(22, '2019-01-31', 'Chapitre 4 : un vent glacial ', '<p>Lorem Elsass ipsum picon bi&egrave;re adipiscing bissame Kabinetpapier non dui Heineken sed m&eacute;t&eacute;or risus, semper mollis wurscht wie id, Yo d&ucirc;. ac turpis, Verdammi sit id so salu schpeck libero. Chulien ac blottkopf, Christkindelsm&auml;rik lotto-owe elit leo ante et morbi knepfle Wurschtsalad aliquam quam. senectus ftomi! geht\'s gal r&eacute;chime yeuh. Sp&auml;tzle Oberschaeffolsheim Salu bissame dignissim Hans sed leverwurscht und rossbolla tristique porta libero, gravida s\'guelt tellus consectetur nullam Strasbourg Huguette turpis sit sagittis gewurztraminer purus amet, quam, elementum Carola Pfourtz ! libero, hopla Chulia Roberstau eleifend rhoncus Oberschaeffolsheim Gal. Gal ! m&auml;nele sit lacus condimentum ornare ornare tchao bissame baeckeoffe eget hop auctor, placerat schneck munster kougelhopf ge&iuml;z barapli Richard Schirmeck mamsell knack flammekueche tellus varius pellentesque vielmols, Salut bisamme hopla schnaps suspendisse hoplageiss kartoffelsalad rucksack messti de Bischheim DNA, hopla dolor hopla Pellentesque Miss Dahlias n&uuml;dle vulputate bredele Mauris ch\'ai in, Morbi non amet Racing. kuglopf ullamcorper habitant Coop&eacute; de Truchtersheim leo amet commodo merci vielmols jetz gehts los chambon</p>'),
(20, '2019-01-17', 'Chapitre 3 : Il neige !', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus sed quam id enim finibus faucibus. Aenean blandit eu urna nec dapibus. Duis nec sem sed nisi molestie scelerisque et eget eros. Donec lobortis sem quis pellentesque ultricies. Morbi egestas ex quis tortor porta tincidunt. Fusce aliquam lorem nulla, ut rhoncus neque egestas vitae. Donec interdum arcu a nunc ullamcorper, eget iaculis arcu pretium. Donec pellentesque ex vitae vehicula egestas. Aliquam justo eros, luctus non posuere quis, egestas quis massa. Sed in porttitor magna. Etiam non iaculis nisl, tincidunt ullamcorper erat.</p>\r\n<p>&nbsp;</p>\r\n<p style=\"box-sizing: border-box; margin: 0px 0px 15px; color: #333333; padding: 0px; text-align: justify; font-family: \'Open Sans\', Arial, sans-serif;\">Etiam facilisis consectetur tellus, ac vehicula purus fermentum a. Suspendisse potenti. Cras elementum molestie nulla eget scelerisque. Cras in tristique leo. Duis blandit quam massa. Praesent auctor erat pretium quam euismod, id egestas orci faucibus. Nulla vestibulum ut justo in accumsan. Fusce elementum consequat accumsan. In eget nibh in ex vestibulum tempus. Praesent commodo purus a nisl gravida sagittis sed nec lacus. Aenean vulputate, tellus quis blandit elementum, leo eros elementum nulla, non varius felis nibh nec felis. Nam at posuere ante. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Ut vitae interdum lectus. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>');

-- --------------------------------------------------------

--
-- Structure de la table `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `comment_date` date NOT NULL,
  `comment_author` varchar(255) NOT NULL,
  `comment_content` text NOT NULL,
  `billet_id` int(11) NOT NULL,
  `comment_statut` varchar(255) NOT NULL DEFAULT 'attente',
  `comment_priority` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `comments`
--

INSERT INTO `comments` (`comment_id`, `comment_date`, `comment_author`, `comment_content`, `billet_id`, `comment_statut`, `comment_priority`) VALUES
(1, '2018-12-03', 'monpseudo', 'ceci est le premier commentaire, sur le premier billet', 1, 'attente', 6),
(5, '2019-01-07', 'cam', 'test form commentaires', 2, 'attente', 0),
(7, '2019-01-16', 'Max', 'Wah super article !', 19, 'valid', 0),
(8, '2019-01-16', 'Fred', 'Hello', 2, 'valid', 0),
(10, '2019-01-17', 'Max', 'Trop bien!', 20, 'valid', 0);

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`user_id`, `login`, `password`) VALUES
(1, 'JForteroche', 'd69700e2a04de9d5fcf3ee83f3d5165aa07a7b7d');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
